﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;
using System.Threading;
using OpenQA.Selenium.Interactions;

namespace tlpAutomatedTests
{
    class Program
    {
        //Used as web browser
        IWebDriver chrome;

        static void Main(string[] args)
        {
        }

        [SetUp]
        public void setUpBrowser()
        {
            chrome = new ChromeDriver();
            chrome.Navigate().GoToUrl("http://www.thelovingpaw.com");
        }

        [Test]
        public void findHomePage()
        {
            chrome.FindElement(By.ClassName("rte"));
        }

        [Test]
        public void findAboutUs()
        {
            chrome.FindElement(By.LinkText("ABOUT US")).Click();
            chrome.FindElement(By.ClassName("rte"));
        }

        [Test]
        public void findNews()
        {
            chrome.FindElement(By.LinkText("NEWS AND EVENTS")).Click();
            chrome.FindElement(By.ClassName("rte"));
        }

        [Test]
        public void findAdoptionResources()
        {
            
            chrome.FindElement(By.LinkText("ADOPTION RESOURCES")).Click();
            chrome.FindElement(By.ClassName("rte"));
        }

        [Test]
        public void findBlog()
        {
            chrome.FindElement(By.LinkText("BLOG")).Click();
            chrome.FindElement(By.ClassName("rte"));
        }

        [Test]
        public void findAdoptionCollection()
        {

            //Referenced: http://testautomationengineer.blogspot.com/2013/12/selenium-webdriver-handling-mouseover.html

            Actions hover = new Actions(chrome);
            hover.MoveToElement(chrome.FindElement(By.PartialLinkText("STORE"))).Build().Perform();
            Thread.Sleep(1000);
            chrome.FindElement(By.LinkText("Adoption Collection")).Click();
            chrome.FindElement(By.ClassName("grid-uniform"));
        }

        [Test]
        public void findBangles()
        {
            Actions hover = new Actions(chrome);
            hover.MoveToElement(chrome.FindElement(By.PartialLinkText("STORE"))).Build().Perform();
            Thread.Sleep(1000);
            chrome.FindElement(By.LinkText("Bangles")).Click();
            chrome.FindElement(By.ClassName("section-header"));
        }

        [Test]
        public void findCharms()
        {
            Actions hover = new Actions(chrome);
            hover.MoveToElement(chrome.FindElement(By.PartialLinkText("STORE"))).Build().Perform();
            Thread.Sleep(1000);
            chrome.FindElement(By.LinkText("Charms")).Click();
            chrome.FindElement(By.ClassName("section-header"));
        }

        [Test]
        public void findDuffleBags()
        {
            Actions hover = new Actions(chrome);
            hover.MoveToElement(chrome.FindElement(By.PartialLinkText("STORE"))).Build().Perform();
            Thread.Sleep(1000);
            chrome.FindElement(By.LinkText("Duffle Bags")).Click();
            chrome.FindElement(By.ClassName("section-header"));
        }

        [Test]
        public void findIDTags()
        {
            Actions hover = new Actions(chrome);
            hover.MoveToElement(chrome.FindElement(By.PartialLinkText("STORE"))).Build().Perform();
            Thread.Sleep(1000);
            chrome.FindElement(By.LinkText("ID Tags")).Click();
            chrome.FindElement(By.ClassName("section-header"));
        }

        [Test]
        public void findTShirts()
        {
            Actions hover = new Actions(chrome);
            hover.MoveToElement(chrome.FindElement(By.PartialLinkText("STORE"))).Build().Perform();
            Thread.Sleep(1000);
            chrome.FindElement(By.LinkText("T-Shirts")).Click();
            chrome.FindElement(By.ClassName("section-header"));
        }

        [Test]
        public void findContactUs()
        {
            chrome.FindElement(By.LinkText("CONTACT US")).Click();
            chrome.FindElement(By.ClassName("rte"));
        }

        [TearDown]
        public void cleanUp()
        {
            chrome.Close();
        }
    }
}
