﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace ImportSettingsTLP
{
    public partial class frmImport : Form
    {

        //References: https://www.youtube.com/watch?v=2ac4hKSfQ9s
        //http://www.seleniumhq.org/download/
        //https://visualstudiogallery.msdn.microsoft.com/27077b70-9dad-4c64-adcf-c7cf6bc9970c

        IWebDriver chrome;

        public frmImport()
        {
            InitializeComponent();
        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            if (validateTxtBoxes())
            {
                break;
            }

            chrome = new ChromeDriver();

            chrome.Navigate().GoToUrl("http://www.shopify.com/login");
            chrome.FindElement(By.Id("HaveMultipleDomains")).Click();
        }

        private bool validateTxtBoxes()
        {
            if (txtUrl.Text == "")
            {
                return false;
            }

            if (txtUserName.Text == "")
            {
                return false;
            }

            if (txtPassword.Text == "")
            {
                return false;
            }

            return true;

        }
    }
}
